// JavaScript code in script.js
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const startButton = document.getElementById("startButton");
const blockCounter = document.getElementById("blockCounter");
const remainingBlocksSpan = document.getElementById("remainingBlocks");
const gameOverText = document.getElementById("gameOver");
const youWonText = document.getElementById("youWon");

let playing = false;
let blocks = [];
let blockRowCount = 3;
let blockColumnCount = 5;
let blockWidth = 75;
let blockHeight = 20;
let blockPadding = 10;
let blockOffsetTop = 30;
let blockOffsetLeft = 30;
let paddleHeight = 10;
let paddleWidth = 75;
let paddleX = (canvas.width - paddleWidth) / 2;
let rightPressed = false;
let leftPressed = false;
let dx = 2;
let dy = -2;
let ballRadius = 10;
let blockCount = blockRowCount * blockColumnCount;

const neonTextCanvas = document.getElementById("neonTextCanvas");
const neonTextCtx = neonTextCanvas.getContext("2d");

function drawNeonText() {
    neonTextCtx.shadowBlur = 10; // Set the shadow blur
    neonTextCtx.shadowColor = "#34eb7d"; // Set the shadow color to match the text color
    neonTextCtx.font = "48px Arial";
    neonTextCtx.fillStyle = "#34eb7d";
    neonTextCtx.fillText("NE   N", 70, 60);
    neonTextCtx.fillStyle = "#FFFFFF";
    neonTextCtx.beginPath();
    neonTextCtx.ellipse(156, 43, 19, 20, 0, 0, Math.PI * 2);
    neonTextCtx.fill();
    neonTextCtx.closePath();
    /*neonTextCtx.fillStyle = "#FFFFFF";
    neonTextCtx.fillText("O", 138, 60);*/
    neonTextCtx.fillStyle = "#34eb7d";
    neonTextCtx.fillText("CRUSHER", 240, 60);
    neonTextCtx.shadowBlur = 0; // Reset the shadow after drawing the text
  }
  

drawNeonText();


function initBlocks() {
  for (let c = 0; c < blockColumnCount; c++) {
    blocks[c] = [];
    for (let r = 0; r < blockRowCount; r++) {
      blocks[c][r] = { x: 0, y: 0, status: 1 };
    }
  }
}

function drawBlocks() {
    ctx.shadowBlur = 20; // Set the shadow blur
    ctx.shadowColor = "#0095DD"; // Set the shadow color to match the block color
    for (let c = 0; c < blockColumnCount; c++) {
      for (let r = 0; r < blockRowCount; r++) {
        if (blocks[c][r].status === 1) {
          let blockX = c * (blockWidth + blockPadding) + blockOffsetLeft;
          let blockY = r * (blockHeight + blockPadding) + blockOffsetTop;
          blocks[c][r].x = blockX;
          blocks[c][r].y = blockY;
          ctx.beginPath();
          ctx.rect(blockX, blockY, blockWidth, blockHeight);
          ctx.fillStyle = "#0095DD";
          ctx.fill();
          ctx.closePath();
        }
      }
    }
    ctx.shadowBlur = 0; // Reset the shadow after drawing the blocks
  }  

function collisionDetection() {
  for (let c = 0; c < blockColumnCount; c++) {
    for (let r = 0; r < blockRowCount; r++) {
      let b = blocks[c][r];
      if (b.status === 1) {
        let blockX = c * (blockWidth + blockPadding) + blockOffsetLeft;
        let blockY = r * (blockHeight + blockPadding) + blockOffsetTop;
        if (
          ball.x + ballRadius > blockX &&
          ball.x - ballRadius < blockX + blockWidth &&
          ball.y + ballRadius > blockY &&
          ball.y - ballRadius < blockY + blockHeight
        ) {
          if (
            ball.x > blockX &&
            ball.x < blockX + blockWidth &&
            (ball.y - dy <= blockY || ball.y - dy >= blockY + blockHeight)
          ) {
            dy = -dy; // Vertical collision
          } else if (
            ball.y > blockY &&
            ball.y < blockY + blockHeight &&
            (ball.x - dx <= blockX || ball.x - dx >= blockX + blockWidth)
          ) {
            dx = -dx; // Horizontal collision
          } else {
            dx = -dx; // Corner collision
            dy = -dy;
          }
          b.status = 0;
          blockCount--;
          remainingBlocksSpan.textContent = blockCount;
          if (blockCount === 0) {
            youWon();
          }
        }
      }
    }
  }

  // Check collisions with paddle
  if (
    ball.x + ballRadius > paddleX &&
    ball.x - ballRadius < paddleX + paddleWidth &&
    ball.y + ballRadius > canvas.height - paddleHeight
  ) {
    dy = -dy; // Reverse ball direction if colliding with paddle
  }
}

function drawBall() {
    ctx.shadowBlur = 20; // Set the shadow blur
    ctx.shadowColor = "#FFFFFF"; // Set the shadow color to match the ball color
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, ballRadius, 0, Math.PI * 2);
    ctx.fillStyle = "#FFFFFF";
    ctx.fill();
    ctx.closePath();
    ctx.shadowBlur = 0; // Reset the shadow after drawing the ball
  }  

function drawPaddle() {
    ctx.shadowBlur = 20; // Set the shadow blur
    ctx.shadowColor = "#34eb7d"; // Set the shadow color to match the paddle color
    ctx.beginPath();
    ctx.rect(paddleX, canvas.height - paddleHeight, paddleWidth, paddleHeight);
    ctx.fillStyle = "#34eb7d";
    ctx.fill();
    ctx.closePath();
    ctx.shadowBlur = 0; // Reset the shadow after drawing the paddle
  }
  

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBlocks();
  drawBall();
  drawPaddle();
  collisionDetection();

  if (ball.x + dx > canvas.width - ballRadius || ball.x + dx < ballRadius) {
    dx = -dx;
  }
  if (ball.y + dy < ballRadius) {
    dy = -dy;
  } else if (ball.y + dy > canvas.height - ballRadius) {
    if (ball.x > paddleX && ball.x < paddleX + paddleWidth) {
      dy = -dy;
    } else {
      gameOver();
    }
  }

  if (rightPressed && paddleX < canvas.width - paddleWidth) {
    paddleX += 7;
  } else if (leftPressed && paddleX > 0) {
    paddleX -= 7;
  }

  ball.x += dx;
  ball.y += dy;

  if (playing) {
    requestAnimationFrame(draw);
  }
}

function startGame() {
  playing = true;
  blockCount = blockRowCount * blockColumnCount;
  remainingBlocksSpan.textContent = blockCount;
  initBlocks();
  ball = { x: canvas.width / 2, y: canvas.height - 30 };
  paddleX = (canvas.width - paddleWidth) / 2;
  gameOverText.style.display = "none"; // Hide "GAME OVER" text
  youWonText.style.display = "none"; // Hide "YOU WON" text
  startButton.style.display = "none"; // Hide "Start Game" button
  draw();
}

function gameOver() {
  playing = false;
  gameOverText.style.display = "block";
  startButton.style.display = "block"; // Show "Start Game" button
}

function youWon() {
  playing = false;
  youWonText.style.display = "block";
  startButton.style.display = "block"; // Show "Start Game" button
}

startButton.addEventListener("click", startGame);

document.addEventListener("keydown", function (e) {
  if (e.key === "d" || e.key === "D") {
    rightPressed = true;
  } else if (e.key === "a" || e.key === "A") {
    leftPressed = true;
  }
});

document.addEventListener("keyup", function (e) {
  if (e.key === "d" || e.key === "D") {
    rightPressed = false;
  } else if (e.key === "a" || e.key === "A") {
    leftPressed = false;
  }
});

